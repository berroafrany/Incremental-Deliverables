﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{

    // Frany Berroa
    // February 9, 2025
    // Final Project - Incremental Deliverables

    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }
        //JC - all functions go here
        int calculateAge(DateTime dob)

        {
            //JC - today - dob in years calculation
            DateTime today = DateTime.Now;
            TimeSpan ts2 = today - dob;
            //JC - remove - this was to show the age
           int age = ts2.Days / 365;
           //  MessageBox.Show(age.ToString());
            return ts2.Days/365;
        }
        private void MCDOB_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void BTNGo_Click(object sender, EventArgs e)
        {
           // string input = Console.ReadLine(MCDOB);
            {
                //JC - I changed the line below to get the value from the calendar
                DateTime dob = MCDOB.SelectionStart;
                int verifyage = calculateAge(dob);
                if (verifyage >= 6)
                {
                    AboutYou f2 = new AboutYou();
                    f2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Come back when you are 6 years old or older");
                }


            }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
    }
}
