﻿namespace Final_Project
{
    partial class AboutYou
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutYou));
            this.label1 = new System.Windows.Forms.Label();
            this.TBDreamState = new System.Windows.Forms.TextBox();
            this.BTNSave = new System.Windows.Forms.Button();
            this.BTNSpillBeans = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TBNum1 = new System.Windows.Forms.TextBox();
            this.TBNum2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.BTNTryItOut = new System.Windows.Forms.Button();
            this.kskskks = new System.Windows.Forms.Label();
            this.TBName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.RBSummer = new System.Windows.Forms.RadioButton();
            this.RBSpring = new System.Windows.Forms.RadioButton();
            this.RBWinter = new System.Windows.Forms.RadioButton();
            this.RBFall = new System.Windows.Forms.RadioButton();
            this.GBSeason = new System.Windows.Forms.GroupBox();
            this.BTNGo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.GBSeason.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(9, 320);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the name of a state you would like to visit";
            // 
            // TBDreamState
            // 
            this.TBDreamState.Location = new System.Drawing.Point(12, 351);
            this.TBDreamState.Name = "TBDreamState";
            this.TBDreamState.Size = new System.Drawing.Size(206, 20);
            this.TBDreamState.TabIndex = 1;
            // 
            // BTNSave
            // 
            this.BTNSave.Location = new System.Drawing.Point(24, 377);
            this.BTNSave.Name = "BTNSave";
            this.BTNSave.Size = new System.Drawing.Size(67, 25);
            this.BTNSave.TabIndex = 2;
            this.BTNSave.Text = "Save Me!";
            this.BTNSave.UseVisualStyleBackColor = true;
            this.BTNSave.Click += new System.EventHandler(this.BTNSave_Click);
            // 
            // BTNSpillBeans
            // 
            this.BTNSpillBeans.Location = new System.Drawing.Point(133, 377);
            this.BTNSpillBeans.Name = "BTNSpillBeans";
            this.BTNSpillBeans.Size = new System.Drawing.Size(88, 38);
            this.BTNSpillBeans.TabIndex = 3;
            this.BTNSpillBeans.Text = "See what other have said!";
            this.BTNSpillBeans.UseVisualStyleBackColor = true;
            this.BTNSpillBeans.Click += new System.EventHandler(this.BTNSpillBeans_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(12, 452);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Let\'s get a random #";
            // 
            // TBNum1
            // 
            this.TBNum1.Location = new System.Drawing.Point(28, 498);
            this.TBNum1.Name = "TBNum1";
            this.TBNum1.Size = new System.Drawing.Size(60, 20);
            this.TBNum1.TabIndex = 5;
            this.TBNum1.TextChanged += new System.EventHandler(this.TBNum1_TextChanged);
            // 
            // TBNum2
            // 
            this.TBNum2.Location = new System.Drawing.Point(115, 498);
            this.TBNum2.Name = "TBNum2";
            this.TBNum2.Size = new System.Drawing.Size(59, 20);
            this.TBNum2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 482);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Enter a number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 482);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Enter another number";
            // 
            // BTNTryItOut
            // 
            this.BTNTryItOut.Location = new System.Drawing.Point(61, 534);
            this.BTNTryItOut.Name = "BTNTryItOut";
            this.BTNTryItOut.Size = new System.Drawing.Size(72, 29);
            this.BTNTryItOut.TabIndex = 9;
            this.BTNTryItOut.Text = "Try It Out!";
            this.BTNTryItOut.UseVisualStyleBackColor = true;
            this.BTNTryItOut.Click += new System.EventHandler(this.BTNTryItOut_Click);
            // 
            // kskskks
            // 
            this.kskskks.AutoSize = true;
            this.kskskks.BackColor = System.Drawing.Color.Transparent;
            this.kskskks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kskskks.ForeColor = System.Drawing.Color.MediumOrchid;
            this.kskskks.Location = new System.Drawing.Point(19, 27);
            this.kskskks.Name = "kskskks";
            this.kskskks.Size = new System.Drawing.Size(138, 16);
            this.kskskks.TabIndex = 10;
            this.kskskks.Text = "What\'s your name?";
            // 
            // TBName
            // 
            this.TBName.Location = new System.Drawing.Point(27, 62);
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(146, 20);
            this.TBName.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(292, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 44);
            this.button1.TabIndex = 12;
            this.button1.Text = "Let\'s get the current weather";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(279, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(191, 191);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // RBSummer
            // 
            this.RBSummer.AutoSize = true;
            this.RBSummer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBSummer.ForeColor = System.Drawing.Color.MediumPurple;
            this.RBSummer.Location = new System.Drawing.Point(13, 26);
            this.RBSummer.Name = "RBSummer";
            this.RBSummer.Size = new System.Drawing.Size(73, 19);
            this.RBSummer.TabIndex = 14;
            this.RBSummer.TabStop = true;
            this.RBSummer.Text = "Summer";
            this.RBSummer.UseVisualStyleBackColor = true;
            // 
            // RBSpring
            // 
            this.RBSpring.AutoSize = true;
            this.RBSpring.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBSpring.ForeColor = System.Drawing.Color.MediumPurple;
            this.RBSpring.Location = new System.Drawing.Point(13, 49);
            this.RBSpring.Name = "RBSpring";
            this.RBSpring.Size = new System.Drawing.Size(61, 19);
            this.RBSpring.TabIndex = 15;
            this.RBSpring.TabStop = true;
            this.RBSpring.Text = "Spring";
            this.RBSpring.UseVisualStyleBackColor = true;
            // 
            // RBWinter
            // 
            this.RBWinter.AutoSize = true;
            this.RBWinter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBWinter.ForeColor = System.Drawing.Color.MediumPurple;
            this.RBWinter.Location = new System.Drawing.Point(13, 72);
            this.RBWinter.Name = "RBWinter";
            this.RBWinter.Size = new System.Drawing.Size(60, 19);
            this.RBWinter.TabIndex = 16;
            this.RBWinter.TabStop = true;
            this.RBWinter.Text = "Winter";
            this.RBWinter.UseVisualStyleBackColor = true;
            this.RBWinter.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // RBFall
            // 
            this.RBFall.AutoSize = true;
            this.RBFall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBFall.ForeColor = System.Drawing.Color.MediumPurple;
            this.RBFall.Location = new System.Drawing.Point(13, 95);
            this.RBFall.Name = "RBFall";
            this.RBFall.Size = new System.Drawing.Size(45, 19);
            this.RBFall.TabIndex = 17;
            this.RBFall.TabStop = true;
            this.RBFall.Text = "Fall";
            this.RBFall.UseVisualStyleBackColor = true;
            this.RBFall.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // GBSeason
            // 
            this.GBSeason.BackColor = System.Drawing.Color.Transparent;
            this.GBSeason.Controls.Add(this.BTNGo);
            this.GBSeason.Controls.Add(this.RBFall);
            this.GBSeason.Controls.Add(this.RBWinter);
            this.GBSeason.Controls.Add(this.RBSpring);
            this.GBSeason.Controls.Add(this.RBSummer);
            this.GBSeason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBSeason.ForeColor = System.Drawing.Color.BlueViolet;
            this.GBSeason.Location = new System.Drawing.Point(72, 145);
            this.GBSeason.Name = "GBSeason";
            this.GBSeason.Size = new System.Drawing.Size(146, 143);
            this.GBSeason.TabIndex = 18;
            this.GBSeason.TabStop = false;
            this.GBSeason.Text = "Pick a season!";
            // 
            // BTNGo
            // 
            this.BTNGo.Location = new System.Drawing.Point(103, 106);
            this.BTNGo.Name = "BTNGo";
            this.BTNGo.Size = new System.Drawing.Size(37, 31);
            this.BTNGo.TabIndex = 18;
            this.BTNGo.Text = "Go";
            this.BTNGo.UseVisualStyleBackColor = true;
            this.BTNGo.Click += new System.EventHandler(this.BTNGo_Click);
            // 
            // AboutYou
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Final_Project.Properties.Resources.USA_Hearts;
            this.ClientSize = new System.Drawing.Size(929, 629);
            this.Controls.Add(this.GBSeason);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.kskskks);
            this.Controls.Add(this.BTNTryItOut);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TBNum2);
            this.Controls.Add(this.TBNum1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BTNSpillBeans);
            this.Controls.Add(this.BTNSave);
            this.Controls.Add(this.TBDreamState);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AboutYou";
            this.Text = "Let\'s Get to Know each other";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.GBSeason.ResumeLayout(false);
            this.GBSeason.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBDreamState;
        private System.Windows.Forms.Button BTNSave;
        private System.Windows.Forms.Button BTNSpillBeans;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBNum1;
        private System.Windows.Forms.TextBox TBNum2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BTNTryItOut;
        private System.Windows.Forms.Label kskskks;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton RBSummer;
        private System.Windows.Forms.RadioButton RBSpring;
        private System.Windows.Forms.RadioButton RBWinter;
        private System.Windows.Forms.RadioButton RBFall;
        private System.Windows.Forms.GroupBox GBSeason;
        private System.Windows.Forms.Button BTNGo;
    }
}