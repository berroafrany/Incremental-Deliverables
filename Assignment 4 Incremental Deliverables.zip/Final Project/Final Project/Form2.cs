﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
    // Frany Berroa
    // Updated Feb 10, 2025

{
    public partial class AboutYou : Form
    {
        string textFile = "Secret.txt";
        Random random = new Random();
        public AboutYou()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void BTNSave_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText(textFile))
            {
                writer.WriteLine(TBDreamState.Text);
            }
        }

        private void BTNSpillBeans_Click(object sender, EventArgs e)
        {
            string line;
            try
            {
                using (StreamReader reader = new StreamReader(textFile))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        MessageBox.Show(line);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BTNTryItOut_Click(object sender, EventArgs e)
        {
            if ((int.TryParse(TBNum1.Text, out int box1)) && (int.TryParse(TBNum2.Text, out int box2)))

            {
                int randomNumber = random.Next(box1, box2 + 1);
                MessageBox.Show("Your random number is -> " + randomNumber);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string url = "https://www.weather.com/weather/today";
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNGo_Click(object sender, EventArgs e)
        {
            if (RBSpring.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Spring.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBFall.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Fall.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBWinter.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Winter.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBSummer.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Summer.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
        }

        private void TBNum1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
