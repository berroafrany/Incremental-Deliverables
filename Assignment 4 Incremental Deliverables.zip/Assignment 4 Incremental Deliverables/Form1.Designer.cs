﻿namespace Assignment_4_Incremental_Deliverables
{
    partial class Secrets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TBSecret = new System.Windows.Forms.TextBox();
            this.BTNSave = new System.Windows.Forms.Button();
            this.BTNTell = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TBNum1 = new System.Windows.Forms.TextBox();
            this.TBNum2 = new System.Windows.Forms.TextBox();
            this.BTNTryItOut = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter a secret";
            // 
            // TBSecret
            // 
            this.TBSecret.Location = new System.Drawing.Point(23, 49);
            this.TBSecret.Name = "TBSecret";
            this.TBSecret.Size = new System.Drawing.Size(188, 20);
            this.TBSecret.TabIndex = 1;
            this.TBSecret.TextChanged += new System.EventHandler(this.TBSecret_TextChanged);
            // 
            // BTNSave
            // 
            this.BTNSave.Location = new System.Drawing.Point(23, 75);
            this.BTNSave.Name = "BTNSave";
            this.BTNSave.Size = new System.Drawing.Size(66, 38);
            this.BTNSave.TabIndex = 2;
            this.BTNSave.Text = "Save Me!";
            this.BTNSave.UseVisualStyleBackColor = true;
            this.BTNSave.Click += new System.EventHandler(this.BTNSave_Click);
            // 
            // BTNTell
            // 
            this.BTNTell.Location = new System.Drawing.Point(117, 81);
            this.BTNTell.Name = "BTNTell";
            this.BTNTell.Size = new System.Drawing.Size(94, 32);
            this.BTNTell.TabIndex = 3;
            this.BTNTell.Text = "Spill the beans!!!";
            this.BTNTell.UseVisualStyleBackColor = true;
            this.BTNTell.Click += new System.EventHandler(this.BTNTell_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(380, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Let\'s get a random #";
            // 
            // TBNum1
            // 
            this.TBNum1.Location = new System.Drawing.Point(355, 138);
            this.TBNum1.Name = "TBNum1";
            this.TBNum1.Size = new System.Drawing.Size(47, 20);
            this.TBNum1.TabIndex = 5;
            // 
            // TBNum2
            // 
            this.TBNum2.Location = new System.Drawing.Point(440, 138);
            this.TBNum2.Name = "TBNum2";
            this.TBNum2.Size = new System.Drawing.Size(54, 20);
            this.TBNum2.TabIndex = 6;
            // 
            // BTNTryItOut
            // 
            this.BTNTryItOut.Location = new System.Drawing.Point(416, 180);
            this.BTNTryItOut.Name = "BTNTryItOut";
            this.BTNTryItOut.Size = new System.Drawing.Size(68, 32);
            this.BTNTryItOut.TabIndex = 7;
            this.BTNTryItOut.Text = "Try it Out!";
            this.BTNTryItOut.UseVisualStyleBackColor = true;
            this.BTNTryItOut.Click += new System.EventHandler(this.BTNTryItOut_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(323, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Enter a number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(437, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Enter another number";
            // 
            // Secrets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Assignment_4_Incremental_Deliverables.Properties.Resources.Numbers;
            this.ClientSize = new System.Drawing.Size(715, 530);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BTNTryItOut);
            this.Controls.Add(this.TBNum2);
            this.Controls.Add(this.TBNum1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BTNTell);
            this.Controls.Add(this.BTNSave);
            this.Controls.Add(this.TBSecret);
            this.Controls.Add(this.label1);
            this.Name = "Secrets";
            this.Text = "Secrets";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBSecret;
        private System.Windows.Forms.Button BTNSave;
        private System.Windows.Forms.Button BTNTell;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBNum1;
        private System.Windows.Forms.TextBox TBNum2;
        private System.Windows.Forms.Button BTNTryItOut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

