﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4_Incremental_Deliverables

    // Frany Berroa
    // Feb 10, 2025
    // Secret Program with random # generator
{
    public partial class Secrets : Form
    {
        string textFile = "Secret.txt";
        Random random = new Random();

        public Secrets()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BTNSave_Click(object sender, EventArgs e)
        {
                using (StreamWriter writer = File.AppendText(textFile))
                {
                    writer.WriteLine(TBSecret.Text);
                }
        }

        private void TBSecret_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTNTell_Click(object sender, EventArgs e)
        {
            string line;
            try
            {
                using (StreamReader reader = new StreamReader(textFile))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        MessageBox.Show(line);
                    }
                }
            }
                catch (Exception ex)
                {
                MessageBox.Show(ex.Message);
                }
               
        }

        private void BTNTryItOut_Click(object sender, EventArgs e)
        {
            if ((int.TryParse(TBNum1.Text, out int box1)) && (int.TryParse(TBNum2.Text, out int box2)))

            {
                int randomNumber = random.Next(box1, box2 + 1);           
                MessageBox.Show("Your random number is -> " + randomNumber);
               
            }
                
               
        }

        private void BTNTime_Click(object sender, EventArgs e)
        {

            
            }
    }
}
